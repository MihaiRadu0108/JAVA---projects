package ExerciseWeek1;

public class Exercise1Week {
    public static void main(String[] args) {

        int day = 1;
        String month = "August";
        System.out.println("My birthday is on " + day + " " + month);

        String firstName = "Mihai";
        String lastName = "Radu";
        String fullName = firstName + " " + lastName;
        System.out.println("Hello, my naem is " + fullName + ".");
        System.out.println("There are " + fullName.length() + " letters in my name");

        double fahrenheit = 54;
        double celsius = 0;
        celsius = (fahrenheit - 32) *5 /9;
        System.out.println("The temperature is " + celsius);


    }
}