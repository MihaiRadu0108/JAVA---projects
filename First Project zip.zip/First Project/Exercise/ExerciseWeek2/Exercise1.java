package ExerciseWeek2;

import java.util.Scanner;

public class Exercise1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Is it snowing outside (true / false)? :");
        boolean isSnowing = scanner.nextBoolean();

        System.out.println("Is it raining outside (true / false)? :");
        boolean isRaining = scanner.nextBoolean();

        System.out.println("What's the temperature outside? :");
        double temperature = scanner.nextDouble();


        if (isSnowing == true || isRaining == true || temperature < 50){
            System.out.println("Let's stay home");
        }else {
            System.out.println("Let's go out");
        }


    }
}