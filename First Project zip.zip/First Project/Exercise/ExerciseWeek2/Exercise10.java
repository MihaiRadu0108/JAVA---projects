package ExerciseWeek2;


public class Exercise10 {

    public static void main(String[] args) {

        String[] weekdays = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
        for (int i = weekdays.length - 1; i >= 0; i--) {
            System.out.println(weekdays[i]);
        }

    }
}
