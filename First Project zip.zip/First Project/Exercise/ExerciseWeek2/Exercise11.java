package ExerciseWeek2;

import java.util.Scanner;

public class Exercise11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Number of words: ");
        int numberOfWords = scanner.nextInt();
        scanner.nextLine();

        String[] sentance = new String[numberOfWords];
        for (int i = 0 ; i < numberOfWords ; i++){
            System.out.println("Enter the word " + (i + 1) + ":");
            String wordsInTheSentance = scanner.nextLine();
            sentance[i]=wordsInTheSentance;
        }

        System.out.println("Enter the word to verify if it is in the sentance: ");
        String wordToVf = scanner.nextLine();
        System.out.println(indexOfFirstOccurrence(sentance,wordToVf));




    }
    public static int indexOfFirstOccurrence(String[] stringArray, String target){
        for (int i = 0 ; i < stringArray.length ; i++){
            if(stringArray[i].equals(target)){
                return i;
            }
        }
        return -1;

    }
}
