package ExerciseWeek2.Exercise12RECAPITULARE;

import java.time.LocalDate;
import java.time.Period;

public class Company {

    private Employee[] employees;

    public void showExistingEmployees(){
        for (Employee element:employees){
            System.out.println(element);
        }
    }

    public void showNumberOfEmployeesWithSeniorityGreaterThan(int years){
        int numberOfEmployees = 0;
        for (Employee element : employees) {
            LocalDate curentDate= LocalDate.now();
            Period period = Period.between(element.getDateOfEmployment(),curentDate);
            if (period.getYears() >= years){
                numberOfEmployees++;
            }
        }
        System.out.println("Numarul angajatilor cu o vechime mai mare de " + years + "este : " + numberOfEmployees);
    }
}
