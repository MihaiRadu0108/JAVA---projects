package ExerciseWeek2.Exercise12RECAPITULARE;

import java.time.LocalDate;

public class CompanyMain {
    public static void main(String[] args) {
        Employee mihai = new Employee("r.mihai.a@gmail.com" , "Radu Mihai", LocalDate)
    }
}
