package ExerciseWeek2.Exercise12RECAPITULARE;

import java.time.LocalDate;

public class Employee {

    private LocalDate dateOfEmployment;
    private String name;
    private String emailAdress;
    private int salary;
    private int daysOfHoliday;

    public LocalDate getDateOfEmployment() {
        return dateOfEmployment;
    }
    public Employee(String emailAdress, String name, LocalDate dateOfEmployment){
        this.name = name;
        this.dateOfEmployment = dateOfEmployment;

    }
}
