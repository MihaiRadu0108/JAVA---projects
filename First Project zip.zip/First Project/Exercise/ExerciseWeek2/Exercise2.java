package ExerciseWeek2;

import java.util.Scanner;

public class Exercise2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Write the time: ");
        double time = scanner.nextDouble();
        String dayTime;

        if (time >= 5 && time < 12) {
            dayTime = "Morning.";
            System.out.println(dayTime);
        } else if (time >= 12 && time < 20) {
            dayTime = "Daytime.";
            System.out.println(dayTime);
        }else {
            dayTime = "Night.";
            System.out.println(dayTime);

        }

    }
}
