package ExerciseWeek2;

import java.util.Scanner;

public class Exercise3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("1 = Monday");
        System.out.println("2 = Tuesday");
        System.out.println("3 = Wednesday");
        System.out.println("4 = Thursday");
        System.out.println("5 = Friday");
        System.out.println("6 = Saturday");
        System.out.println("7 = Sunday");
        System.out.println("Enter the day: ");

        int dayOfTheWeek = scanner.nextInt();
        System.out.println("Is it holiday (true / false) :");
        boolean holiday = scanner.nextBoolean();

        if (dayOfTheWeek <= 5 && holiday == false){
            System.out.println("Wake up at 7!");
        }else {
            System.out.println("Sleep in");
        }

    }
}
