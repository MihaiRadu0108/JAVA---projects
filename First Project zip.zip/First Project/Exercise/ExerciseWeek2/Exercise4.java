package ExerciseWeek2;

import java.util.Scanner;

public class Exercise4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("1 = Monday");
        System.out.println("2 = Tuesday");
        System.out.println("3 = Wednesday");
        System.out.println("4 = Thursday");
        System.out.println("5 = Friday");
        System.out.println("6 = Saturday");
        System.out.println("7 = Sunday");
        System.out.println("Enter the day: ");

        int dayOfTheWeek = scanner.nextInt();
        String schedule;

        switch (dayOfTheWeek){
            case 1:
                schedule = "Gym in the morning";
                System.out.println(schedule);
                break;
            case 2:
                schedule = "Class after work";
                System.out.println(schedule);
                break;
            case 3:
                schedule = "Meeting all day";
                System.out.println(schedule);
                break;
            case 4:
                schedule = "Work from home";
                System.out.println(schedule);
                break;
            case 5:
                schedule = "Game night after work";
                System.out.println(schedule);
                break;
            case 6:
                schedule = "Free";
                System.out.println(schedule);
                break;
            case 7:
                schedule = "Free";
                System.out.println(schedule);
                break;
            default:
                System.out.println("Enter a valid day of the week");
                break;
        }
    }
}
