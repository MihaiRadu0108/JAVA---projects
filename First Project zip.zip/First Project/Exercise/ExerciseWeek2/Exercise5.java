package ExerciseWeek2;

import java.util.Scanner;

public class Exercise5 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number to verify it's parity: ");
        int numberToBeVerif = scanner.nextInt();


        Exercise5 parityOfNumber = new Exercise5();
        parityOfNumber.isPrime(numberToBeVerif);


    }

    public void isPrime(int x){
        if (x % 2 == 0){
            System.out.println("Number " + x + " is even");
        }else {
            System.out.println("Number " + x + " is odd");
        }
    }

}
