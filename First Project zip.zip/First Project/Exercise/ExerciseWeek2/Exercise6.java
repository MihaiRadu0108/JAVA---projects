package ExerciseWeek2;

import java.util.Scanner;

public class Exercise6 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce a number : ");
        double numberTBC = scanner.nextInt();

        Exercise6 number = new Exercise6();
        number.absoluteNumber(numberTBC);

    }

    public void absoluteNumber(double x){
        if (x < 0){
            System.out.println(-x);
        }else {
            System.out.println(x);
        }
    }

}
