package ExerciseWeek2;

import java.util.Scanner;

public class Exercise7 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce the cost of the meal: ");
        double mealCost = scanner.nextDouble();

        Exercise7 mealPr = new Exercise7();
        mealPr.calculateTip(mealCost);

    }
    public void calculateTip(double costOfTheMeal){
        double costPr = (costOfTheMeal * 15) / 100;
        System.out.println("15% of the meal is :" + "\n" + costPr);
        return ;
    }
}
