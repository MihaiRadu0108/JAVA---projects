package ExerciseWeek2;

import java.util.Scanner;

public class Exercise8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number to calculate it's factorial: ");
        int factorial = scanner.nextInt();

        int result = 1;

        for (int i = 1 ; i <= factorial ; i++){
            result = result * i;

        }
        System.out.println(result);
    }
}
