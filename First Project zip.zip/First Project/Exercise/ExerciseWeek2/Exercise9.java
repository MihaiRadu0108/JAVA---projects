package ExerciseWeek2;

import java.util.Scanner;

public class Exercise9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the balance to start with: ");
        int balance = scanner.nextInt();
        int years = 0;

        while (balance < 1000000){
            years++;
            balance = balance + (balance * 15) / 100;
        }
        System.out.println("It will take you " + years + " years to get " + balance);

    }
}
