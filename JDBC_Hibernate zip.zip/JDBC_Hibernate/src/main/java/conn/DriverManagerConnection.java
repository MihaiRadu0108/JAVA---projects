package conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DriverManagerConnection {
    public static void main(String[] args) {

        try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda54","root","piticu2000")) {
            System.out.println("DriverManager connection works");
        }catch (SQLException e){
            e.printStackTrace();
        }

    }
}
