package queryExecution;

import java.sql.*;

public class CallableStatementMethod {
    protected void getBooks(){
        try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda54","root","piticu2000")){
            CallableStatement callableStatement = connection.prepareCall(" { CALL GetBooks() } ");
            final ResultSet resultSet = callableStatement.executeQuery();
            while (resultSet.next()){
                System.out.println("Id " + resultSet.getInt(1));
                System.out.println("Title " + resultSet.getString(2));
                System.out.println("Type " + resultSet.getString(3));
                System.out.println("Description " + resultSet.getString(4));

            }


        }catch (SQLException e){
            e.printStackTrace();
        }



    }

}
