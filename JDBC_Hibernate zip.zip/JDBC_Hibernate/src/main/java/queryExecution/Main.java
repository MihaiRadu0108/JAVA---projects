package queryExecution;

public class Main {
    public static void main(String[] args) {
        StatementsMethods statementsMethods = new StatementsMethods();
    //    statementsMethods.execute();
    //    statementsMethods.executeUpdate();
    //    statementsMethods.executeQuery();
        PreparedStatementMethods preparedStatementMethods = new PreparedStatementMethods();
    //    preparedStatementMethods.executePreparedStatement();
        CallableStatementMethod callableStatementMethod = new CallableStatementMethod();
        callableStatementMethod.getBooks();
    }
}
