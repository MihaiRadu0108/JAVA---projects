package queryExecution;

import java.sql.*;

public class PreparedStatementMethods {
    protected void executePreparedStatement(){

        try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda54","root","piticu2000")) {
            PreparedStatement preparedStatement = connection.prepareStatement("Select * from Book where type= ? or description= ?");
            preparedStatement.setString(1,"Programming");
            preparedStatement.setString(2, "test");

            final ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()){
                System.out.println("Id " + resultSet.getInt(1));
                System.out.println("Title " + resultSet.getString(2));
                System.out.println("Type " + resultSet.getString(3));
                System.out.println("Description " + resultSet.getString(4));
            }


        }catch (SQLException e){
            e.printStackTrace();
        }

    }
}
