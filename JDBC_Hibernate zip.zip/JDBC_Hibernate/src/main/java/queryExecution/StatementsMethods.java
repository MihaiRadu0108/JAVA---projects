package queryExecution;

import java.sql.*;

public class StatementsMethods {
    protected void execute(){
        try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda54","root","piticu2000")) {

            Statement statement = connection.createStatement();
            boolean isResultSetExecuted = statement.execute("create table BOOK(Id INT PRIMARY KEY ,Title VARCHAR(32) NOT NULL, Type VARCHAR(32), Description VARCHAR(50))");
            System.out.println(isResultSetExecuted);

        }catch (SQLException e){
            e.printStackTrace();
        }


    }

    protected void executeUpdate(){

        try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda54","root","piticu2000")){
            Statement statement = connection.createStatement();
            int rowCount = statement.executeUpdate("insert into Book values(1, 'Java beginner', 'Programming', 'Programming in Java from scratch')");
            System.out.println(rowCount);
        }catch (SQLException e){
            e.printStackTrace();
        }


    }

    protected void executeQuery(){

        try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda54","root","piticu2000")) {

            Statement statement = connection.createStatement();
            final ResultSet resultSet = statement.executeQuery("Select * from Book");
            while (resultSet.next()){

                System.out.println("Id " + resultSet.getInt(1));
                System.out.println("Title " + resultSet.getString(2));
                System.out.println("Type " + resultSet.getString(3));
                System.out.println("Description " + resultSet.getString(4));
            }

        }catch (SQLException e){
            e.printStackTrace();
        }

    }

}
