package task1;

public class Task1Main {
    public static void main(String[] args) {
        Task1Methods createTable = new Task1Methods();
        // createTable.createTableBook();
        createTable.insertIntoMovies();

    }


}
