package task1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Task1Methods {
    protected void createTableBook(){
        try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda54", "root", "piticu2000")) {

            Statement statement = connection.createStatement();
            statement.executeUpdate("create table movies(Id INT AUTO_INCREMENT PRIMARY KEY, Title VARCHAR (255), Type VARCHAR (255), yearOfRelease INT)");
            statement.executeUpdate("");

        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    protected void insertIntoMovies(){
        try(Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sda54", "root", "piticu2000")) {
            Statement statement = connection.createStatement();
            Statement statement1 = connection.createStatement();
            Statement statement2 = connection.createStatement();
            statement.executeUpdate("INSERT INTO movies (Id, Title,  Type, yearOfRelease) VALUES(1, 'FastOfFurious9', 'ActionMovie', 2023)");
            statement1.executeUpdate("INSERT INTO movies (Id, Title,  Type, yearOfRelease) VALUES(2, 'The Nun', 'ActionMovie', 2019)");
            statement2.executeUpdate("INSERT INTO movies (Id, Title,  Type, yearOfRelease) VALUES(3, 'Forest Gump', 'ActionMovie', 2022)");

        }catch (SQLException e){
            e.printStackTrace();
        }
    }
}
