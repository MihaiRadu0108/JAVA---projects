package ro.sda.enums.part1;

public enum Coffee {
    LATTE,
    ESPRESSO,
    AMERICANO
}
