package ro.sda.enums.part1;

public class Main {
    public static void main(String[] args) {

        Coffee myCoffe = Coffee.LATTE;

        System.out.println(myCoffe);
        System.out.println(myCoffe.ordinal());

        Coffee anotherCoffee = Coffee.ESPRESSO;
        System.out.println(anotherCoffee);
        System.out.println(anotherCoffee.ordinal());


        Coffee coffee2 = Coffee.valueOf("AMERICANO");
        System.out.println(coffee2);
        System.out.println(coffee2.ordinal());


    }
}
