package ro.sda.enums.part2;

public enum Coffee {
    LATTE(10,"Coffee with milk"),
    AMERICANO(8,"Long coffee"),
    ESPRESSO(6,"Short coffee");

    private int price;
    private String description;

    //constructors in enums are private by default
    private Coffee(int price, String description) {
        this.price = price;
        this.description = description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Coffee{" +
                "price=" + price +
                ", description='" + description + '\'' +
                '}';
    }
}
