package ro.sda.enums.part2;

public class Main {
    public static void main(String[] args) {

        Coffee latte = Coffee.LATTE;

        System.out.println("Order of late in enum is: " + latte.ordinal());
        System.out.println("Price of latte: " + latte.getPrice());
        System.out.println("Description of latte: " + latte.getDescription());
        System.out.println("Latte toString() -> " + latte.toString());

        int price = calculatePrice("AMERICANO");
        System.out.println("Price of " + Coffee.AMERICANO.name() + " in RON is: " + price);

    }

    private static int calculatePrice(String requested){
        Coffee coffee = Coffee.valueOf("AMERICANO");
        int price = coffee.getPrice();
        return price * 5;
    }

}
