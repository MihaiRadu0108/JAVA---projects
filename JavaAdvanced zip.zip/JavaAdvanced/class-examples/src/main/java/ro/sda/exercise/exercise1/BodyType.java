package ro.sda.exercise.exercise1;

/*Create an enum called BodyType which has the following values: STAR, PLANET, MOON, DWARF_PLANET;*/
public enum BodyType {
    STAR,
    PLANET,
    MOON,
    DWARF_PLANET;

}
