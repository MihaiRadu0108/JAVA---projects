package ro.sda.exercise.exercise1;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/*
  Create an abstract class HeavenlyBody which would be our base class that every celestial body will implement
  The class should have the following instance variables:
  - a Set of HeavenlyBody objects called satellites set
  - orbitalPeriod which is a double
  - Key (which is another class, a static nested class in the HeavenlyBody)
      For this Key class, it should be a nested static class in the HeavenlyBody and should have the following fields:
      - String name;
      - BodyType bodyType;
      The following methods should be also included in the Key class:
      - a constructor which initialize both fields
      - getName() - getter for the name
      - getBodyType() - getter for the bodyType
      - hashCode() - method should be overridden
      - equals() - method should be overridden
      - toString() - should be also overridden

  The following methods should be also included in the HeavenlyBody class:
  - a constructor which takes as parameters a name(String), orbitalPeriod(double), and bodyType(BodyType) -
  creates a new Key by calling Key's constructor and initialize the satellites set with a new HashSet<>();
  - getKey() - getter for the key
  - getOrbitalPeriod() - getter for orbitalPeriod
  - getSatellites() - getter for satellites set (use Collections.unmodifiableSet(this.satellites))
  - boolean addSatellite(HeavenlyBody moon) - add a new item to the satellites set (return true or false if
   the operation succeeded)
  - override equals() - it should only use keys for comparing objects
  - override hashcode() - it should only use key hashcode method
  - override toString() - print key name, bodyType and orbitalPeriod*/
public abstract class HeavenlyBody {

    private Key key;
    private double orbitalPeriod;
    private Set<HeavenlyBody> satellites;

    public HeavenlyBody(String name , double orbitalPeriod, BodyType bodyType) {

        this.key = new Key(name, bodyType);
        this.orbitalPeriod = orbitalPeriod;
        this.satellites = new HashSet<>();

    }

    public static class Key {

        private String name;
        private BodyType bodyType;

        public Key(String name, BodyType bodyType) {
            this.name = name;
            this.bodyType = bodyType;
        }

        public String getName() {
            return name;
        }

        public BodyType getBodyType() {
            return bodyType;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Key key = (Key) o;
            return Objects.equals(name, key.name) && bodyType == key.bodyType;
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, bodyType);
        }

        @Override
        public String toString() {
            return this.name + ": " + this.bodyType;
        }

    }


}