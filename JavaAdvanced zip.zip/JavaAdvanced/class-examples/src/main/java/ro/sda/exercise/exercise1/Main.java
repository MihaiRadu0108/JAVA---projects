package ro.sda.exercise.exercise1;

public class Main {
}
