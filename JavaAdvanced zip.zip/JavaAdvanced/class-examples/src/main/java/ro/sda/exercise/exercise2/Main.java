package ro.sda.exercise.exercise2;

public class Main {
    public static void main(String[] args) {

        Team<> real = new Team("Real Madrid");
        Team<> barcelona = new Team("Barcelona");

        real.matchResult(barcelona, 1, 0);


    }
}
