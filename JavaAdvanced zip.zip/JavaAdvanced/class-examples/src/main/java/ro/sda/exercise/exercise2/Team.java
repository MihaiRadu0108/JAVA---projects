package ro.sda.exercise.exercise2;

public class Team<T> {

    private String name;
    private int matchesPlayed;
    private int won;
    private int lost;
    private int tied;

    public Team(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }

    public void matchResult(Team<T> opponent, int ourScore, int theirScore){

        String message;
        if (ourScore>theirScore){
            this.won++;
            opponent.lost++;
            message = "beat"
        }
        else if (ourScore<theirScore){
            opponent.won++;
            this.lost++;
            message = "lost to";
        }
        else {
            opponent.tied++;
            this.tied++;
            message = "tied with";
        }
        this.matchesPlayed++;
        opponent.matchesPlayed++;
        System.out.println(this.name + message + opponent.name + " -> " + ourScore + "-" + theirScore);



    }





}
