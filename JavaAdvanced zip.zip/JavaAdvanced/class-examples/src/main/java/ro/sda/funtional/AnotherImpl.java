package ro.sda.funtional;

public class AnotherImpl implements MyFuncInterface{

    @Override
    public void execute(String param){

        System.out.println("Hello " + param.toUpperCase() + "! Welcome back!");

    }

}
