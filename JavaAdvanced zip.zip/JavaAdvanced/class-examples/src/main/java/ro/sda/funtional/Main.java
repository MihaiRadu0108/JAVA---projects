package ro.sda.funtional;

public class Main {
    public static void main(String[] args) {

        MyFuncInterface impl = new MyImplementation();
        impl.execute("Catalin");

        impl = new AnotherImpl();
        impl.execute("Teodor");

        MyFuncInterface lambda = (String p) -> {
            System.out.println("Hello " + p.toLowerCase() + "! I'm your first lambda expression");
        };

        System.out.println("BEFORE EXECUTE");
        lambda.execute("CODRUT");

        System.out.println("-------------------");

        MyFuncInterface anotherMethod = (String input) ->
                System.out.println("You are still learning lambda" + input + "!");

        anotherMethod.execute("Andrei");




    }
}
