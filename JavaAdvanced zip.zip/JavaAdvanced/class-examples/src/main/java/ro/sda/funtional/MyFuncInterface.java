package ro.sda.funtional;

@FunctionalInterface
public interface MyFuncInterface {
    public abstract void execute(String param);




}
