package ro.sda.funtional;

public class MyImplementation implements MyFuncInterface{
    @Override
    public void execute(String param){
        System.out.println("Hello " + param + "! You are learning funtional java!");
    }

}
