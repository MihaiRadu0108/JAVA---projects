package ro.sda.inner_class;

public class Laptop {

    private double price;

    public double getPrice() {
        return price;
    }

    public  Laptop(double price) {
        this.price = price;
    }
    //inner class
    class Processor{
        private int numberOfCores;

        private String manufacturer;

        public Processor(int numberOfCores, String manufacturer){
            this.numberOfCores = numberOfCores;
            this.manufacturer = manufacturer;
        }

        public int getNumberOfCores() {
            return numberOfCores;
        }

        public String getManufacturer() {
            return manufacturer;
        }
    }


}
