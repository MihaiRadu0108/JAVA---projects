package ro.sda.inner_class;

public class Main {
    public static void main(String[] args) {

        Laptop myLaptop = new Laptop(2000);

        System.out.println("Price of myLaptop is: " + myLaptop.getPrice());

        Laptop.Processor processor = myLaptop.new Processor(4, "Apple");

        System.out.println("Manufacturer: " + processor.getManufacturer());
        System.out.println("Number of cores: " + processor.getNumberOfCores());


    }
}
