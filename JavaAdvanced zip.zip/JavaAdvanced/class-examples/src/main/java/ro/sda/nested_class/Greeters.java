package ro.sda.nested_class;

public class Greeters {

    static class Romanian{

        public void greet(){
            System.out.println("Buna ziua!");


        }
    }

    static class Portuguese{
        public void greet(){
            System.out.println("Ola!");
        }
    }

}
