package ro.sda.nested_class;

import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {

        Greeters.Romanian romanianGreeter = new Greeters.Romanian();

        Greeters.Portuguese portugueseGreeter = new Greeters.Portuguese();

        romanianGreeter.greet();

        portugueseGreeter.greet();

        System.out.println("--------------------------------");

        HashMap<String, Integer> map = new HashMap<>();
        map.put("Catalin", 25);
        map.put("Messi", 35);

        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("KEY: " + entry.getKey());
            System.out.println("VALUE: " + entry.getValue());
        }

    }
}
