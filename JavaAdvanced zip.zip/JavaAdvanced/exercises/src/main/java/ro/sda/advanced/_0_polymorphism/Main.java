package ro.sda.advanced._0_polymorphism;

// Create a base class called Car
// It should have a few fields that would be appropriate for a generic car class.
// engine, cylinders, wheels, etc.
// Constructor should initialize cylinders (number of) and name, and set wheels to 4
// and engine to true. Cylinders and names would be passed parameters.
//
// Create appropriate getters
//
// Create some methods like startEngine, accelerate, and brake
//
// show a message for each in the base class
// Now create 3 subclasses for your favorite vehicles.
// Override the appropriate methods to demonstrate polymorphism in use.
// put all classes in the one java file (this one).
public class Main {

    public static void main(String[] args) {

        Ford f = new Ford("Mondeo", 4, true);
        Mazda m = new Mazda("CX5",4,true);
        Car c = new Car("Logan",4,true);

        f.startEngine();
        f.accelerate();
        m.startEngine();
        m.accelerate();
        m.accelerate(30);
        c.startEngine();
        c.accelerate();


    }
}

class Car {
    private String name;
    private int numberOfCylinders;
    private boolean hasEngine;

    public Car(String name, int numberOfCylinders, boolean hasEngine) {
        this.name = name;
        this.numberOfCylinders = numberOfCylinders;
        this.hasEngine = hasEngine;
    }

    public String getName() {
        return name;
    }

    public int getNumberOfCylinders() {
        return numberOfCylinders;
    }

    public boolean hasEngine() {
        return hasEngine;
    }

    public void startEngine() {
        System.out.println("Car -> startEngine()");
    }

    public void accelerate() {
        System.out.println("Car -> accelerate()");
    }

}

class Ford extends Car {
    public Ford(String name, int numberOfCylinders, boolean hasEngine) {
        super(name, numberOfCylinders, hasEngine);
    }

    @Override
    public void startEngine() {
        System.out.println("Ford -> startEngine()");
    }

    @Override
    public void accelerate() {
        System.out.println("Ford -> accelerate()");
    }

}

class Mazda extends Car {
    public Mazda(String name, int numberOfCylinders, boolean hasEngine) {
        super(name, numberOfCylinders, hasEngine);
    }

    @Override
    public void startEngine() {
        System.out.println("Mazda -> startEngine()");
    }

    @Override
    public void accelerate() {
        System.out.println("Mazda -> accelerate()");
    }

    // method overloading
    public void accelerate(int speed){
        System.out.println("Mazda increased speed with " + speed);
    }
}