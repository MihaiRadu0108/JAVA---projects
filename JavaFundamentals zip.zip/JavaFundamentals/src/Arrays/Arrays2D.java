package Arrays;

public class Arrays2D {

    public static void main(String[] args) {

        int[][] note = new int[2][3];
        note[0][0] = 10;
        note[0][1] = 9;
        note[0][2] = 10;
        note[1][0] = 8;
        note[1][1] = 9;
        note[1][2] = 10;

        int sumOfElements = 0;
        int countOfElements = 0;
        for (int i = 0 ; i < note.length ; i++ ){
            for (int j = 0 ; j < note[i].length ; j++){
                System.out.println(note[i][j]);
                sumOfElements = sumOfElements + note[i][j];

            }
            countOfElements = countOfElements + note[i].length;

        }
        System.out.println("Media aritmetica a notelor este: " + sumOfElements / (double)countOfElements);

        System.out.println("________________");

        String[][] words = {{"SDA", "Mihai", "Radu"},{"Alexandru"} ,{"Cristi" , "Aura"}};
        int countOfLetters = 0;
        for(int i = 0 ; i < words.length ; i++){
            for (int j = 0 ; j < words[i].length ; j++){
                countOfLetters = countOfLetters + words[i][j].length();

            }
        } System.out.println("Numarul de litere este: " + countOfLetters);
        System.out.println("_______________");

        String propozitia = new String();
        for(int i = 0 ; i < words.length ; i++){
            for (int j = 0 ; j < words[i].length ; j++){

            propozitia = propozitia + words[i][j] + " ";
            }

        } System.out.println("Propozitia este: " + propozitia + ".");


    }

}
