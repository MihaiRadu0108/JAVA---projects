package Arrays;

public class ArraysExamples {

    public static void main(String[] args) {

        int[] numbers = new int[3]; //declararea unui array de int-uri
                                    // cu lungimea de n elemente

        numbers[0] = 10;  //initializarea valorii de pe pozitia
        numbers[1] = -5;  //fiecarui numar din array
        numbers[2] = 0;

        int[] intNumbers = {5, -1, 2, 6}; //declararea si initializarea valorilor
                                          //intr-un array

        intNumbers[2] = 3; //schimbarea numarului de pe pozitia
                           // aleasa intr-un array

        System.out.println(numbers[1]);
        System.out.println(intNumbers[intNumbers.length - 1]);

        String[] words = {"azi", "curs", "sda"};
        System.out.println(words[0]);

        String[] texts = new String[4];
        texts[2] = "Ana are mere";

        if(texts[0] != null){
            System.out.println(texts[0].length());//arunca NullPointerException fara if diferit de null
        }
    }
}
