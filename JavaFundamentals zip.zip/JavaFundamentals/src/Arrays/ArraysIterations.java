package Arrays;

public class ArraysIterations {

    public static void main(String[] args) {

        int[] numbers = {1, 2, 3, 4, 5, 6, 7};

        for (int i = 0 ; i < numbers.length ; i++){
            System.out.println(numbers[i]);
        }
        int sumOfNumbers = 0;
        for (int i = 0 ; i < numbers.length ; i++){

            sumOfNumbers = sumOfNumbers + numbers[i];

        }
        System.out.println("Suma numerelor este : " + sumOfNumbers);

        System.out.println("________________");

        int[] otherNumbers = new int[10];
        for (int i = 0 ; i < otherNumbers.length ; i++){
            otherNumbers[i] = i+1;
        }


        for (int i = otherNumbers.length - 1 ; i >= 0 ; i--){
            System.out.println(otherNumbers[i]);
        }

        System.out.println("_______________");


    }

}
