package Conditionals;

import java.util.Scanner;

public class ExercitiuIfElse {
    public static void main(String[] args) {

        Scanner wordToVrf = new Scanner(System.in);
        System.out.println("Introduceti un cuvant de la tastatura: ");
        String wordIntroduced = wordToVrf.nextLine();

        StringBuilder reversedWord = new StringBuilder();
        reversedWord.append(wordIntroduced);
        reversedWord.reverse();

        System.out.println("Cuvantul inversat este: " + reversedWord);

        if (wordIntroduced.contains(reversedWord)) {
            System.out.println("Cuvantul este palindrom ");
        } else {
            System.out.println("Cuvantul nu este palindrom ");
        }


    }


}
