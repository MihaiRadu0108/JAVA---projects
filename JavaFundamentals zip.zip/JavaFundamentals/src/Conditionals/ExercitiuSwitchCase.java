package Conditionals;

import java.util.Scanner;

public class ExercitiuSwitchCase {
    public static void main(String[] args) {
        Scanner firstNumber = new Scanner(System.in);
        System.out.println("Introduceti un primul numar de la tastatura: ");
        double firstNumberIntrroduced = firstNumber.nextDouble();

        Scanner secondNumber = new Scanner(System.in);
        System.out.println("Introduceti al doilea numar de la tastatura: ");
        double secondNumberIntrroduced = secondNumber.nextDouble();

        Scanner operatii = new Scanner(System.in);
        System.out.println("Introduceti operatia matematica");
        char operation = operatii.nextLine().charAt(0);
        switch (operation){
            case '+':
                System.out.println("Rezulatatul este: " + (firstNumberIntrroduced + secondNumberIntrroduced));
                break;
            case '-':
                System.out.println("Rezulatatul este: " + (firstNumberIntrroduced - secondNumberIntrroduced));
                break;
            case '/':
                System.out.println("Rezulatatul este: " + (firstNumberIntrroduced / secondNumberIntrroduced));
                break;
            case '*':
                System.out.println("Rezulatatul este: " + (firstNumberIntrroduced * secondNumberIntrroduced));
            default:
                System.out.println("Simbol incorect ");






        }

    }
}
