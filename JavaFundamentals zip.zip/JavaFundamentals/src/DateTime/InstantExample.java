package DateTime;

import java.time.Instant;

public class InstantExample {
    public static void main(String[] args) {
        Instant instantObject = Instant.now();
        System.out.println(instantObject);
    }
}
