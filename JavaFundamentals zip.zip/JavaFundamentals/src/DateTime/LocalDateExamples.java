package DateTime;

import java.time.LocalDate;
import java.time.Month;

public class LocalDateExamples {
    public static void main(String[] args) {
        LocalDate curentLocalDate = LocalDate.now();
        System.out.println("Data curenta este: " + curentLocalDate);

        LocalDate anotherLocalDate = LocalDate.of(2023, 6, 20);
        LocalDate futureLocaldate = LocalDate.of(2024, Month.FEBRUARY, 14);

        System.out.println("O alta data setata de noi: " + anotherLocalDate);
        System.out.println("Valentines day from next year: " + futureLocaldate);

        String formatDate = curentLocalDate.getDayOfMonth() + "." + curentLocalDate.getMonth() + "." + curentLocalDate.getYear();
        System.out.println(formatDate);


    }
}
