package DateTime;

import java.time.LocalDateTime;
import java.time.Month;

public class LocalDateTimeExamples {

    public static void main(String[] args) {
        LocalDateTime curentLocalDateTime = LocalDateTime.now();
        System.out.println(curentLocalDateTime);

        LocalDateTime secondLocalDateTime = LocalDateTime.of(2022, Month.MARCH, 20, 15 , 20, 15 );
        System.out.println(secondLocalDateTime);

        String formatDateTime = curentLocalDateTime.getDayOfMonth() + "." + curentLocalDateTime.getMonthValue()
                + "." +curentLocalDateTime.getYear() + " " + curentLocalDateTime.getHour()
                + ":" + curentLocalDateTime.getMinute() + ":" + curentLocalDateTime.getSecond();
        System.out.println(formatDateTime);


    }

}
