package DateTime;

import java.time.LocalTime;

public class LocalTimeExamples {

    public static void main(String[] args) {
        LocalTime localTimeObject = LocalTime.now();
        System.out.println("Ora curenta este" + localTimeObject);

        LocalTime finalCourseTime = LocalTime.now().withHour(14).withMinute(0).withSecond(0).withNano(0);
        System.out.println("Ora la care terminam cursul azi este: " + finalCourseTime);

        System.out.println("Peste 5 ore va fi: " + localTimeObject.plusHours(5));
        System.out.println("Acum 30 minute a fost: " + localTimeObject.minusMinutes(30));

        String formatTime = localTimeObject.getHour() + "-" + localTimeObject.getMinute() + "-" + localTimeObject.getSecond();
        System.out.println(formatTime);


    }

}
