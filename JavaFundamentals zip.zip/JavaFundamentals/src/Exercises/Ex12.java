package Exercises;

public class Ex12 {
    import java.util.HashSet;

    public class Solution {

        public static String solution(String S) {
            HashSet<Character> seen = new HashSet<>();
            HashSet<Character> seenMultipleTimes = new HashSet<>();

            for (int i = 0; i < S.length(); i++) {
                char c = S.charAt(i);
                if (seen.contains(c)) {
                    seenMultipleTimes.add(c);
                } else {
                    seen.add(c);
                }
            }

            if (!seenMultipleTimes.isEmpty()) {
                return seenMultipleTimes.iterator().next().toString();
            } else {
                return null;
            }
        }

        public static void main(String[] args) {
            String s = "abcdefghijklmnopqrstuvwxyzAABB";
            String duplicate = solution(s);
            if (duplicate != null) {
                System.out.println("The character '" + duplicate + "' occurs multiple times in the string.");
            } else {
                System.out.println("No character occurs more than once in the string.");
            }
        }
    }
}
