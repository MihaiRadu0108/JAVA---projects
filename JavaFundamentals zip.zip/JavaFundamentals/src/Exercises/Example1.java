package Exercises;

import java.util.Scanner;

public class Example1 {

    public static void main(String[] args) {

        System.out.println("Introduce radius:");
        Scanner scanner = new Scanner(System.in);
        float r = scanner.nextFloat();
        float diameter = 2 * r;
        double perimeter = diameter * Math.PI;
        System.out.printf("The perimeter is: %f " , perimeter);

    }
}
