package Exercises;


import java.util.HashSet;
import java.util.Scanner;

class Solution {
    public static String solution(String S) {
        // Implement your solution here
        HashSet<Character> seen = new HashSet<>();

        for (int i = 0; i < S.length(); i++) {
            char c = S.charAt(i);
            if (seen.contains(c)) {
                return String.valueOf(c);
            } else {
                seen.add(c);
            }
        }

        return null;
    }

    public static void main(String[] args) {
        String s = "abaifgf";
        String duplicate = solution(s);
        if (duplicate != null) {
            System.out.println("The character '" + duplicate + "' occurs twice in the string.");
        } else {
            System.out.println("No character occurs twice in the string.");
        }
    }
}
