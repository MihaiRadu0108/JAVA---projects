package Exercises;

import java.util.Scanner;

public class Example2 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce weight in kilograms: ");
        float weight = scanner.nextFloat();
        System.out.println("Introduce height in cm: ");
        int height = scanner.nextInt();
        double heightinMeter = height/100d;
        double bmi = weight/Math.pow(heightinMeter,2);
        System.out.println("The BMI(Body Mass Index) is: " + bmi);
        if (bmi > 18.5 && bmi < 24.9){
            System.out.println("Your BMI is optimal");
        }else {
            System.out.println("Your BMI is not optimal");
        }
    }
}
