package Exercises;

import java.util.Scanner;

public class Example3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce number 1: ");
        int a = scanner.nextInt();
        System.out.println("Introduce number 2: ");
        int b = scanner.nextInt();
        System.out.println("Introduce number 3: ");
        int c = scanner.nextInt();
        double delta = Math.pow(b,2) - 4 * a * c;
        if (delta < 0){
            System.out.println("Delta is negative.");

        }else {
            double x1 = (-b - Math.sqrt(delta)) / 2 * a;
            double x2 = (-b + Math.sqrt(delta)) / 2 * a;
            System.out.println("x1 is: " + x1 + "x2 is: " + x2);
        }
    }
}
