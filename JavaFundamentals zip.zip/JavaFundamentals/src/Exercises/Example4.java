package Exercises;

import java.util.Scanner;

public class Example4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int numb = scanner.nextInt();
        for (int i = 1; i <= numb; i++){
            System.out.println(i);
            if(i % 3 == 0){
                System.out.println("Fizz");
            }
            if(i % 7 == 0){
                System.out.println("Buzz");
            }
            if(i % 3 == 0 && i % 7 ==0){
                System.out.println("Fizz Buzz");
            }

        }

    }
}
