package Exercises;

import java.util.Scanner;

public class Example5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int numb = scanner.nextInt();
        for (int i = 2; i < numb; i++) {
            if(numb % i == 0){
                System.out.println(i);
            }
        }
    }

}

