package Exercises;

import java.util.Scanner;

public class Example6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int numb = scanner.nextInt();
        double sum  = 0;

        for (int i = 1; i <= numb; i++){
            sum = sum + (1.0/i);
        }
        System.out.println("Harmonic sum is: " + sum);
    }
}
