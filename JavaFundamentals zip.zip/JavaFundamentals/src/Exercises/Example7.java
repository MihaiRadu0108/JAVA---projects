package Exercises;

import java.util.Scanner;

public class Example7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int numb = scanner.nextInt();
        System.out.println(fibonacciNumber(numb));
    }

    public static int fibonacciNumber(int number) {
        if (number == 0) {
            return 1;
        }
        if (number == 1) {
            return 1;
        }
        return fibonacciNumber(number - 1) + fibonacciNumber(number - 2);
    }
}

