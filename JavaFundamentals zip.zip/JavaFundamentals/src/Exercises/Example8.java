package Exercises;

import java.util.Scanner;

public class Example8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number: ");
        String numberlenght = scanner.nextLine();
        int sum = 0;
        int number = Integer.parseInt(numberlenght);

        for (int i =  0; i < numberlenght.length(); i++){
            sum = sum + (number % 10);
            number = number / 10;
        }
        System.out.println("The sum of digits of the number is: " + sum);
    }
}
