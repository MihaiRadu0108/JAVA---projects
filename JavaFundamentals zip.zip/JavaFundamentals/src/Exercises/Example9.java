package Exercises;

import java.util.Scanner;

public class Example9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the words: ");
        String words = scanner.nextLine();
        int wordsLenght = words.length();
        int count = 0;
        for (int i = 0 ; i < words.length() ; i++){
            char chars = words.charAt(i);
            if (chars == ' ' ){
                count++;
            }

        }
        double pr = (count * 100) / wordsLenght;
        System.out.println(pr + "% of " + wordsLenght);

    }
}
