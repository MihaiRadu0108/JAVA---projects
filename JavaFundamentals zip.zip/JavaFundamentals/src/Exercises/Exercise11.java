package Exercises;

import java.util.HashSet;

public class Exercise11 {
    public static Character findDuplicateLetter(String s) {
        HashSet<Character> seen = new HashSet<>();
        HashSet<Character> seenMultipleTimes = new HashSet<>();

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (seen.contains(c)) {
                seenMultipleTimes.add(c);
            } else {
                seen.add(c);
            }
        }

        if (!seenMultipleTimes.isEmpty()) {
            return seenMultipleTimes.iterator().next();
        } else {
            return null;
        }
    }

    public static void main(String[] args) {
        String s = "abcdefghijklmnopqrstuvwxyzAABB";
        Character duplicate = findDuplicateLetter(s);
        if (duplicate != null) {
            System.out.println("The character '" + duplicate + "' occurs multiple times in the string.");
        } else {
            System.out.println("No character occurs more than once in the string.");
        }
    }
}

