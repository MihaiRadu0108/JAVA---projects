package Loops;

public class DoWhileExample {

    public static void main(String[] args) {

        int number = 1;
        do {
            System.out.println("Hello, the current number value is : " + number);
            number++;
        } while (number < 10);
        System.out.println("Finalizarea programului");


    }
}
