package Loops;

import java.util.Scanner;

public class ExercitiuBlockCounts {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Scrieti cate nivele are piramida:");
        int numberOfLevels = scanner.nextInt();

        int numbersOfCubes = 0;

        for (int i = 1; i <= numberOfLevels; i++) {
            numbersOfCubes = numbersOfCubes + i * i;
        }

        System.out.println("Numarul total de cuburi din piramida este:" + numbersOfCubes);

    }

}
