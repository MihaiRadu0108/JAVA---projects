package Loops;

import java.util.Random;
import java.util.Scanner;

public class ExercitiuDiceGame {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Random random = new Random();

        int diceOne;
        int diceTwo;

        do {
            diceOne = random.nextInt(1 , 7);
            diceTwo = random.nextInt(1 , 7);
            System.out.println("Zarul I este: "+ diceOne + "\n" +  " Zarul II este: " + diceTwo);

        }while (diceOne != diceTwo );
        System.out.println("Jocaul s-a terminat, ai castigat!");
    }

}
