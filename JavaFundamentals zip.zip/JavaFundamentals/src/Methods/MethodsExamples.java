package Methods;

public class MethodsExamples {

    int ceva;//pt a se apela intr-o clasa statica trebuie pus "static" inaintea tipului variabilei

    public static void main(String[] args) {
        int ceva; //nu se apeleaza cu cel de sus pentru ca nu se afla in clasa static
        // , dar se poate apela daca punem static inainte.
        printName("Mihai");
        sum(5, 10);

        int sumOfNumbers = sumOfIntNumbers(2, 3);

        System.out.println("Suma numerelor este " + sumOfNumbers);

    }

    public static int sumOfIntNumbers(int numberOne, int numberTwo) {

        return numberOne + numberTwo;

    }

    //metodele cu void nu returneaza nimic

    public static void printName(String name) {

        System.out.println(name);
    }

    public static void sum(int firstNumber, int secondNumber) {

        System.out.println(firstNumber + secondNumber);
    }

}
