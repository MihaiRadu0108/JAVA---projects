package Methods;

import java.util.Scanner;

public class SimpleMethodExamples {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduceti numarul pentru ai verifica paritatea: ");
        int numberIntroduced = scanner.nextInt();

        SimpleMethodExamples paritatea = new SimpleMethodExamples();
        paritatea.checkNumber(numberIntroduced);
        //asa se apeleaza metodele care nu sunt statice
    }

    public void checkNumber(int numberToBeChecked) {

        if (numberToBeChecked % 2 == 0) {
            System.out.println("Numarul " + numberToBeChecked + " este par.");
        } else {
            System.out.println("Numarul " + numberToBeChecked + " este impar");
        }


    }


}
