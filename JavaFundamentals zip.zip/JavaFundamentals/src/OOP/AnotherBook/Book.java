package OOP.AnotherBook;

public class Book {
}
