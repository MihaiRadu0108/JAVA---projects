package OOP.Book;

public class Book {
    public String name;
    private String author;
    private int numberOfPages;

    public void setAuthor(String nameOfAuthor){
        author = nameOfAuthor;
    }


    public void setNumberOfPages(int numberOfPages){
        if(checkNumberOfPages(numberOfPages)){
            this.numberOfPages = numberOfPages;
        }
    }
    boolean checkNumberOfPages(int numberOfPages){ //modificatorul default se poate apela din pachet
        return numberOfPages > 0;
    }

    @Override
    public String toString() {
        return "Book{" +
                "name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", numberOfPages=" + numberOfPages +
                '}';
    }
}
