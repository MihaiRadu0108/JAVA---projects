package OOP.Book;

public class BookTest {
    public void test() {
        Book test = new Book();
        test.checkNumberOfPages(5); // am acces sa apelez metoda din clasa Book
        // cu numele checkNumberOfPages deoarece are modificatorul de acces
        //default si aceasta clasa se afla in acelasi pachet cu clasa Book
    }
}
