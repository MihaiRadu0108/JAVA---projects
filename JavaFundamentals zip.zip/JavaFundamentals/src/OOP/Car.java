package OOP;

public class Car {
    // Zona de declarare a campurilor clasei (fields)
    private String color;
    private int speed;
    private String brand;

    public Car(){

    }
    public Car(String color, int speed, String brand) { // Constructor nu metoda pentru ca nu are tip de returnare
        this.color = color;
        this.speed = speed;
        this.brand = brand;
    }

    // Zona de declarare a metodelor clasei (comportamentele obiectelor)
    public void printCarParameters() {
        System.out.printf("Culoarea masinii este %s, viteza este %s, si marca este %s", color, speed, brand);

    }

    public void setColor(String color) {
        this.color = color; // Cu this. se apeleaza variabila la nivel de clasa
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getColor(){
        return color;
    }
    public int getSpeed(){
        return speed;
    }
    public String getBrand(){
        return brand;
    }

}
