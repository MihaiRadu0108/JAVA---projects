package OOP;

import OOP.Book.Book;

public class Main {
    public static void main(String[] args) {

        Car toyota = new Car();
        Car mazda = new Car();

        toyota.setColor("red");
        toyota.setSpeed(123);
        toyota.setBrand("Toyota");

        mazda.setColor("blue");
        mazda.setSpeed(200);
        mazda.setBrand("Mazda");

        toyota.printCarParameters();
        System.out.println(); //doar ca sa treaca cursorul pe linie noua
        mazda.printCarParameters();

        System.out.println();
        System.out.println(toyota.getColor());
        Car audi = new Car("black", 250, "Audi");


        System.out.println("\n___________________");

        Book luceafarul = new Book();
        luceafarul.setNumberOfPages(100);
        luceafarul.setAuthor("Mihai Eminescu");
        luceafarul.name = "Luceafarul";
        System.out.println(luceafarul);

        OOP.AnotherBook.Book anotherBook = new OOP.AnotherBook.Book(); // importarea unei clase cu acelasi nume


    }


}
