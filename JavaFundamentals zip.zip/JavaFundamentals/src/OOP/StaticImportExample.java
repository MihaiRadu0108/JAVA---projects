package OOP;

import static java.lang.Math.PI;
public class StaticImportExample {
    public static void main(String[] args) {
        System.out.println(PI);
    }
}
