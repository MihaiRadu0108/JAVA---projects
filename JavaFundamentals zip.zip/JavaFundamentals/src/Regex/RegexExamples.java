package Regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExamples {
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile("alo+"); // alo, alooo
        Matcher objectCheck = pattern.matcher("aloooooo");
        System.out.println(objectCheck.matches());

        Pattern secondPattern = Pattern.compile("[a-z]*"); // orice litera mica intre a si z
        Matcher secondMatcher = secondPattern.matcher("dsfgsdagedsasdg");
        System.out.println(secondMatcher.matches());

    }
}
