import java.util.Scanner;

public class ScannerExamples {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Introduceti un text de la tastatura:");
        String valueFromUser = input.nextLine();
        System.out.println(valueFromUser);

        int numberFromImput = input.nextInt();
        input.nextLine(); //trece cursorul pe linnie noua pa urmatoarea citire
        System.out.println("Introduceti un numar de la tastatura:");
        System.out.println("valoarea numerica citita de la tastatura este" + numberFromImput);

        System.out.println("Introduceti true sau false de la tastatura");
        boolean booleanBalue = input.nextBoolean();
        input.nextLine();
        System.out.println("Valorare booleana citita de la tastatura este: " + booleanBalue);

        System.out.println("Introduceti un numar cu virgula");
        double numberWithComma = input.nextDouble();
        System.out.printf("%4.2f" , numberWithComma);



    }
}
