public class StringExamples {
    public static void main(String[] args) {
        String text = "numele meu este Mihai";
        System.out.println(text);
        String anotherText = new String("Ceva");
        System.out.println(anotherText);

        System.out.println(text + " " + anotherText);
        System.out.println(text.concat(anotherText));

        System.out.println(text.contains("Mihai"));
        System.out.println(text.toUpperCase());
        System.out.println(text.length());
        System.out.println(text.indexOf("m")); //numaratoarea incepe de la 0
        System.out.println(text.equals(anotherText));

    }
}
