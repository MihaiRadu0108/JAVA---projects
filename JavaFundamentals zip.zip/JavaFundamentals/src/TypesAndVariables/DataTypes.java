package TypesAndVariables;

public class DataTypes {
    public static void main(String[] args) {
        // cele 4 tipuri de date pentru numere intregi

        byte firstByte = 54; //byte = (-128,127)
        System.out.println(firstByte);

        short firstShort = 128; //short = (-32768,32767)

        int firstInt = 32768;    //int = (-2147483648,2147483647)

        long firstLong = 214748364;
        long sum = Integer.MAX_VALUE + 1L; // L este de la long
        System.out.println(sum);

        //cele 2 tipuri pentru numere reale sau cu virgula

        float  myFloatNumber = 5.5568f; //trebuie pus f de la float ca sa nu fie considerat double
        double myDoubleNumber = 10.509;

        System.out.println(myFloatNumber);
        System.out.printf("%.2f", myDoubleNumber);
        System.out.println("\n"); // \n este comanda pentru a trece pe linie noua
        System.out.printf("%.3f", myFloatNumber);
        System.out.println();


        boolean myBooleanValue = true; // true sau fals
        System.out.println(myBooleanValue);

        char myCharValue = 'a'; // orice tip de caracter fie litera cifra sau simbol
        System.out.println(myCharValue);


    }

}
