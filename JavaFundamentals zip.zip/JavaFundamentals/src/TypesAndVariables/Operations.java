package TypesAndVariables;

public class Operations {
    public static void main(String[] args) {
        int a = 5;
        a += 10;
        System.out.println(a);
        a *= 2;
        System.out.println(a);
        a -= 3;
        System.out.println(a);
        a /= 2;
        System.out.println(a);

        int firstNumber = 5;
        int secondNumber = 2;

        float result = (float) firstNumber / secondNumber; //se numeste 'cast : ()'

        System.out.println(5/2); // acelasi lucru (firstNumber / secondNumber)
        System.out.println(result);

        double division = 7 /(double) 2;
        System.out.println(division);

        int restOfDivision = firstNumber % secondNumber;
        System.out.println(firstNumber % secondNumber);
        System.out.println(restOfDivision);
        System.out.println("x= " + restOfDivision + " orice vrei tu");

        int someVariable = 5;
        // someVariable = someVariable+1; este acelasi lucru ca linia de mai jos ( prescurtare )
        someVariable++;
        System.out.println(someVariable);
        someVariable--; // =//= -1;
        System.out.println(someVariable);

        //operatori de realationare
        boolean checkEqualityBetweenTwoNumbers = someVariable == 5;
        System.out.println(checkEqualityBetweenTwoNumbers);
        boolean checkInequalityBetweenTwoNumbers = someVariable != division;
        System.out.println(checkInequalityBetweenTwoNumbers);

        //operatori logici
        boolean firstBooleanValue = true;
        boolean secondBooleanValue = false;

        System.out.println(firstBooleanValue && secondBooleanValue);
        System.out.println(firstBooleanValue || secondBooleanValue);
        System.out.println(!firstBooleanValue);
        System.out.println(firstBooleanValue && (!secondBooleanValue) || firstBooleanValue);



    }

}
