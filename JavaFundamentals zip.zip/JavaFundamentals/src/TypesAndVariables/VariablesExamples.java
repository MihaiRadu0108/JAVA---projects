package TypesAndVariables;

public class VariablesExamples {

   private int value; // declararea unei variabile globala (intre acoladele clasei)

    /*
    paragraf pentru comentarii foarte lungi
     */
    public static void main(String[] args) {

        int number; // declararea unei variabile locala (in interioriul unei metode)
        number = 5; // initializarea unei variabile
        System.out.println(number);

        int secondNumber = 10; // declarare si inititalizare pe aceeasi linie de cod
        System.out.println(secondNumber);

        boolean is4you = true;

    }

}
