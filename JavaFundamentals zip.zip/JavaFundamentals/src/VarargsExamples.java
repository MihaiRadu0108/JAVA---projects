public class VarargsExamples {

    public static void main(String[] args) {

        VarargsExamples example = new VarargsExamples();
        System.out.println("Suma numerelor variabile este: " + example.calculateSum(2, 4, 6, 7, 5) );

    }
    public int calculateSum(int... numbers){       //nr de argumente variabil

        int sum = 0;
        for (int i = 0 ; i < numbers.length ; i++){
            sum = sum + numbers[i];
        }
        return sum;
    }

    public void test(String name, int... note){



    }

}
