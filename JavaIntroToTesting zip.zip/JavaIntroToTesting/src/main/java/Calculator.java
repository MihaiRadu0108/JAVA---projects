public class Calculator {

    public Double add(double firstNum, double secondNum){
        return firstNum + secondNum;
    }
    public Double subtract(double firstNum, double secondNum){
        if (secondNum <= 0 ){
            return null;
        }
        return firstNum - secondNum;
    }
    public Double multiply(double firstNum, double secondNum){
        return firstNum * secondNum;
    }
    public Double divide(double firstNum, double secondNum){
        return firstNum / secondNum;
    }
    public long reverseSign(long number){
        return -1 * number;
    }

    public static void main(String[] args) {
        System.out.println("\t".length());
    }
}
