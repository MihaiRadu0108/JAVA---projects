import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class CalculatorTest {

    @Test
    public void addTest(){
       //given
        Calculator calculator = new Calculator();
        double givenFirstNum = 10;
        double givenSecondNum = 22;
        Double expectedResult = 32d;
        Double unexpectedResult = 55d;
       //when
        Double  actualResult = calculator.add(givenFirstNum, givenSecondNum);
       //then
        Assertions.assertEquals(expectedResult, actualResult);
        Assertions.assertNotEquals(unexpectedResult, actualResult);
    }

}
