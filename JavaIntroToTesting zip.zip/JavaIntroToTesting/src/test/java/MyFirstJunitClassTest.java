import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class MyFirstJunitClassTest {

    @Test
    public void myFirstTest() {
        System.out.println("Hi from junit.");
    }
    @Test
    public void firstAssertEqualsTest(){
     int sum = 10;
     int firstNum = 8;
     int secondNum = 2;
        Assertions.assertEquals(sum, firstNum + secondNum);
        Assertions.assertNotEquals(sum, 199 + 564);
    }
    @Test
    public void firstAssertNotNullTes() {
        String name = "java";
        String secondName = null; // = String secondname;

        Assertions.assertNotNull(name);
        Assertions.assertNull(secondName);
    }
    @Test
    public void firstAssertTrueFalseTest() {
        boolean isBlack = true;
        Assertions.assertTrue(isBlack);
        Assertions.assertFalse(3 == 7);

    }


}
