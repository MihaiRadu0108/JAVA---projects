public interface FahrenheitTemperature {
    // returns Fahrenheit temperature
    Double getFahrenheitTemperature();
}
