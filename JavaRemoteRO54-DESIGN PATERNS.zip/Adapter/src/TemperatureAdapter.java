public interface TemperatureAdapter {
    // returns Celsius temperature
    Double getCelsiusTemperature();
}
