public class TemperatureAdapterDemo {
    public static void main(String[] args) {

        Thermometer fahrenheitThermometer = new Thermometer();

        TemperatureAdapterImpl temperatureInCelsius = new TemperatureAdapterImpl(fahrenheitThermometer);

        System.out.println("Temperature in Celsius is: " + temperatureInCelsius.getCelsiusTemperature());
    }
}
