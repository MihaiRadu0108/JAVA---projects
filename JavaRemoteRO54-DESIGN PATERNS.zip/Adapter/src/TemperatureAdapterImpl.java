public class TemperatureAdapterImpl implements TemperatureAdapter {
    private Thermometer thermometer;

    public TemperatureAdapterImpl(Thermometer thermometer) {
        this.thermometer = thermometer;
    }

    @Override
    public Double getCelsiusTemperature() {
        return convertFahrenheitToCelsius(thermometer.getFahrenheitTemperature());
    }

    private Double convertFahrenheitToCelsius(Double temperature) {
        return (temperature - 32) * 5/9;
    }
}
