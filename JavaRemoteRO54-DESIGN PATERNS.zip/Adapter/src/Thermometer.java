public class Thermometer implements FahrenheitTemperature {
    @Override
    public Double getFahrenheitTemperature() {
        return 77.0;
    }
}
