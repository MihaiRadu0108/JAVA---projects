public class AnotherPersonBuilder {
    private String firstName;
    private String lastName;
    private Integer age;
    private Character sex;
    private String hairColor;
    private String eyesColour;
    private Integer height;
    private Integer weight;
    private String streetName;
    private Integer streetNo;
    private String city;
    private String county;
    private String country;

    public AnotherPersonBuilder withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public AnotherPersonBuilder withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public AnotherPersonBuilder withAge(Integer age) {
        this.age = age;
        return this;
    }

    public AnotherPersonBuilder withSex(Character sex) {
        this.sex = sex;
        return this;
    }

    public AnotherPersonBuilder withHairColour(String hairColour) {
        this.hairColor = hairColour;
        return this;
    }

    public AnotherPersonBuilder withEyesColour(String eyesColour) {
        this.eyesColour = eyesColour;
        return this;
    }

    public AnotherPersonBuilder withHeight(Integer height) {
        this.height = height;
        return this;
    }

    public AnotherPersonBuilder withWeight(Integer weight) {
        this.weight = weight;
        return this;
    }

    public AnotherPersonBuilder withStreetName(String streetName) {
        this.streetName = streetName;
        return this;
    }

    public AnotherPersonBuilder withStreetNo(Integer streetNo) {
        this.streetNo = streetNo;
        return this;
    }

    public AnotherPersonBuilder withCity(String city) {
        this.city = city;
        return this;
    }

    public AnotherPersonBuilder withCounty(String county) {
        this.county = county;
        return this;
    }

    public AnotherPersonBuilder withCountry(String country) {
        this.country = country;
        return this;
    }

    public AnotherPerson build() {
        return new AnotherPerson(
                firstName,
                lastName,
                age,
                sex,
                hairColor,
                eyesColour,
                height,
                weight,
                streetName,
                streetNo,
                city,
                county,
                country);
    }
}