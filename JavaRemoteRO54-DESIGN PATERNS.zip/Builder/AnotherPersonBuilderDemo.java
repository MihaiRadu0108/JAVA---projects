public class AnotherPersonBuilderDemo {
    public static void main(String[] args) {
        AnotherPerson person = new AnotherPersonBuilder()
                .withFirstName("Ionut")
                .withAge(33)
                .withCity("Filiasi")
                .withSex('M')
                .build();
        System.out.println(person);
    }
}
