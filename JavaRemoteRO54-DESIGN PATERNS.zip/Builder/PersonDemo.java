public class PersonDemo {
    public static void main(String[] args) {
        Person youngMale = new Person("Adrian", "Ionescu", 23, 'M', "blonde", "blue", 178, 60, "Rasaritului", 22, "Bucuresti", "Ilfov", "Romania");
        System.out.println(youngMale);

        Person youngFemale = new Person("Ana", "Maior", 21);
        System.out.println(youngFemale);
    }
}
