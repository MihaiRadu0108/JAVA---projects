public class PersonOptimizedWithBuilder {
    private String firstName;
    private String lastName;
    private Integer age;
    private Character sex;
    private String hairColor;
    private String eyesColour;
    private Integer height;
    private Integer weight;
    private String streetName;
    private Integer streetNo;
    private String city;
    private String county;
    private String country;

    private PersonOptimizedWithBuilder(String firstName, String lastName, Integer age, Character sex, String hairColor, String eyesColour, Integer height, Integer weight, String streetName, Integer streetNo, String city, String county, String country) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.sex = sex;
        this.hairColor = hairColor;
        this.eyesColour = eyesColour;
        this.height = height;
        this.weight = weight;
        this.streetName = streetName;
        this.streetNo = streetNo;
        this.city = city;
        this.county = county;
        this.country = country;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Integer getAge() {
        return age;
    }

    public Character getSex() {
        return sex;
    }

    public String getHairColor() {
        return hairColor;
    }

    public String getEyesColour() {
        return eyesColour;
    }

    public Integer getHeight() {
        return height;
    }

    public Integer getWeight() {
        return weight;
    }

    public String getStreetName() {
        return streetName;
    }

    public Integer getStreetNo() {
        return streetNo;
    }

    public String getCity() {
        return city;
    }

    public String getCounty() {
        return county;
    }

    public String getCountry() {
        return country;
    }

    @Override
    public String toString() {
        return "Person{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", age=" + age +
                ", sex=" + sex +
                ", hairColor='" + hairColor + '\'' +
                ", eyesColour='" + eyesColour + '\'' +
                ", height=" + height +
                ", weight=" + weight +
                ", streetName='" + streetName + '\'' +
                ", streetNo='" + streetNo + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", country='" + country + '\'' +
                '}';
    }

    public static class Builder {
        private String firstName;
        private String lastName;
        private Integer age;
        private Character sex;
        private String hairColor;
        private String eyesColour;
        private Integer height;
        private Integer weight;
        private String streetName;
        private Integer streetNo;
        private String city;
        private String county;
        private String country;

        public Builder withFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder withLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder withAge(Integer age) {
            this.age = age;
            return this;
        }

        public Builder withSex(Character sex) {
            this.sex = sex;
            return this;
        }

        public Builder withHairColour(String hairColour) {
            this.hairColor = hairColour;
            return this;
        }

        public Builder withEyesColour(String eyesColour) {
            this.eyesColour = eyesColour;
            return this;
        }

        public Builder withHeight(Integer height) {
            this.height = height;
            return this;
        }

        public Builder withWeight(Integer weight) {
            this.weight = weight;
            return this;
        }

        public Builder withStreetName(String streetName) {
            this.streetName = streetName;
            return this;
        }

        public Builder withStreetNo(Integer streetNo) {
            this.streetNo = streetNo;
            return this;
        }

        public Builder withCity(String city) {
            this.city = city;
            return this;
        }

        public Builder withCounty(String county) {
            this.county = county;
            return this;
        }

        public Builder withCountry(String country) {
            this.country = country;
            return this;
        }

        public PersonOptimizedWithBuilder build() {
            return new PersonOptimizedWithBuilder(
                    firstName,
                    lastName,
                    age,
                    sex,
                    hairColor,
                    eyesColour,
                    height,
                    weight,
                    streetName,
                    streetNo,
                    city,
                    county,
                    country);
        }
    }
}
