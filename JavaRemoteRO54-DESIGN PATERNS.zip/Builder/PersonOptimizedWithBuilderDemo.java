public class PersonOptimizedWithBuilderDemo {
    public static void main(String[] args) {
        PersonOptimizedWithBuilder person = new PersonOptimizedWithBuilder.Builder()
                .withFirstName("Alexandra")
                .withAge(25)
                .withCity("Brasov")
                .withSex('F')
                .withCountry("RO")
                .build();
        System.out.println(person);

        PersonOptimizedWithBuilder.Builder personBuilder = new PersonOptimizedWithBuilder.Builder();
        personBuilder.withAge(23).withSex('F').withLastName("AAAA");
        PersonOptimizedWithBuilder personX = personBuilder.build();

        PersonOptimizedWithBuilder person2 = new PersonOptimizedWithBuilder.Builder()
                .withFirstName("Ciprian")
                .withLastName("Costache")
                .build();

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("aaaa ");
        System.out.println(stringBuilder);
        stringBuilder.append(3 + " ");
        System.out.println(stringBuilder);
        stringBuilder.append(true + " ");
        System.out.println(stringBuilder);
    }
}
