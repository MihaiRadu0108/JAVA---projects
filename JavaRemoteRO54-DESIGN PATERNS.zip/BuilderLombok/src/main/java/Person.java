import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@AllArgsConstructor
@Builder
public class Person {
    private String firstName;
    private String lastName;
    private Integer age;
    private Character sex;
    private String hairColor;
    private String eyesColour;
    private Integer height;
    private Integer weight;
    private String streetName;
    private Integer streetNo;
    private String city;
    private String county;
    private String country;
}
