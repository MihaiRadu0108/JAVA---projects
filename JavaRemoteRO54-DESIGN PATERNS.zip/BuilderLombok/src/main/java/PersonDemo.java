import org.apache.commons.lang3.text.WordUtils;

public class PersonDemo {
    public static void main(String[] args) {

        Person person = new Person.PersonBuilder()
                .firstName("Albert")
                .age(45)
                .city("Monaco")
                .sex('M')
                .build();
        System.out.println(person);
    }
}
