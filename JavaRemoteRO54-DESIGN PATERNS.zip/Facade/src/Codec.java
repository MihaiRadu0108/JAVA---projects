public interface Codec {
}
