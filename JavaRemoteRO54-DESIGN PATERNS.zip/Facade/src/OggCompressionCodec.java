public class OggCompressionCodec implements Codec {
    public String type = "ogg";
}