public class ClassEagerSingleton {
    private static final ClassEagerSingleton INSTANCE = new ClassEagerSingleton();
    private Integer counter = 0;

    private ClassEagerSingleton() {
    }

    public static ClassEagerSingleton getInstance() {
        return INSTANCE;
    }

    public void incrementCounter() {
        counter++;
    }

    public Integer getCounter() {
        return counter;
    }
}
