public class ClassEagerSingletonDemo {
    public static void main(String[] args) {

        ClassEagerSingleton singletonObject = ClassEagerSingleton.getInstance();
        System.out.println(singletonObject);

        singletonObject.incrementCounter();
        System.out.println("Eager " + singletonObject.getCounter());

        ClassEagerSingleton anotherSingletonObject = ClassEagerSingleton.getInstance();
        System.out.println(anotherSingletonObject);

        anotherSingletonObject.incrementCounter();
        System.out.println("Eager " + anotherSingletonObject.getCounter());
    }
}
