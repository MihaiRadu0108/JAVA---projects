public class ClassLazySingleton {
    private Integer counter = 0;
    private static ClassLazySingleton instance;

    private ClassLazySingleton() {
    }

    public void incrementCounter() {
        counter++;
    }

    public Integer getCounter() {
        return counter;
    }

    public static ClassLazySingleton getInstance() {
        if (instance == null) {
            instance = new ClassLazySingleton();
        }
        return instance;
    }
}
