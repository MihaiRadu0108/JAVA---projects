public class ClassLazySingletonDemo {
    public static void main(String[] args) {

//        ClassLazySingleton exampleNull = null;
//        exampleNull.incrementCounter();

        ClassLazySingleton singletonObject = ClassLazySingleton.getInstance();
        System.out.println(singletonObject);

        singletonObject.incrementCounter();
        System.out.println("Lazy " + singletonObject.getCounter());

        ClassLazySingleton anotherSingletonObject = ClassLazySingleton.getInstance();
        System.out.println(anotherSingletonObject);

        anotherSingletonObject.incrementCounter();
        System.out.println("Lazy " + anotherSingletonObject.getCounter());
        System.out.println("Lazy " + singletonObject.getCounter());
    }
}
