public class ClassLazySingletonDoubleChecked {
    private static ClassLazySingletonDoubleChecked instance;
    private Integer counter = 0;

    private ClassLazySingletonDoubleChecked() {
    }


    public void incrementCounter() {
        counter++;
    }

    public Integer getCounter() {
        return counter;
    }

    public static ClassLazySingletonDoubleChecked getInstance() {
        if (instance == null) {
            synchronized (ClassLazySingletonDoubleChecked.class) {
                if (instance == null) {
                    instance = new ClassLazySingletonDoubleChecked();
                }
            }
        }
        return instance;
    }
}
