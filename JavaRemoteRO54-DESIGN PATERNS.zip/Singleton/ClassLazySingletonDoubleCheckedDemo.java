public class ClassLazySingletonDoubleCheckedDemo {
    public static void main(String[] args) {

        ClassLazySingletonDoubleChecked singletonObject = ClassLazySingletonDoubleChecked.getInstance();
        System.out.println(singletonObject);

        singletonObject.incrementCounter();
        System.out.println("Lazy Double Checked " + singletonObject.getCounter());

        ClassLazySingletonDoubleChecked anotherSingletonObject = ClassLazySingletonDoubleChecked.getInstance();
        System.out.println(anotherSingletonObject);

        anotherSingletonObject.incrementCounter();
        System.out.println("Lazy Double Checked " + anotherSingletonObject.getCounter());
    }
}
