public enum EnumEagerSingleton {
    INSTANCE;

    private Integer counter = 0;

    public Integer getCounter() {
        return counter;
    }

    public void incrementCounter() {
        counter++;
    }
}
