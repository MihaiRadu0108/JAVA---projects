public class EnumEagerSingletonDemo {
    public static void main(String[] args) {

        EnumEagerSingleton singletonObject = EnumEagerSingleton.INSTANCE;
        System.out.println(singletonObject.hashCode());

        singletonObject.incrementCounter();
        System.out.println("Enum Eager " + singletonObject.getCounter());

        EnumEagerSingleton anotherSingletonObject = EnumEagerSingleton.INSTANCE;
        System.out.println(anotherSingletonObject.hashCode());

        anotherSingletonObject.incrementCounter();
        System.out.println("Enum Eager " + anotherSingletonObject.getCounter());
        System.out.println("Enum Eager " + singletonObject.getCounter());

        System.out.println("-----------------");

        EnumEagerSingleton anotherSingletonObject2 = EnumEagerSingleton.INSTANCE;
        System.out.println(anotherSingletonObject2.hashCode());
        System.out.println("Enum Eager " + anotherSingletonObject2.getCounter());
        System.out.println("Enum Eager " + anotherSingletonObject.getCounter());
        System.out.println("Enum Eager " + singletonObject.getCounter());

        singletonObject.incrementCounter();

        System.out.println("Enum Eager " + anotherSingletonObject2.getCounter());
        System.out.println("Enum Eager " + anotherSingletonObject.getCounter());
        System.out.println("Enum Eager " + singletonObject.getCounter());
    }
}
