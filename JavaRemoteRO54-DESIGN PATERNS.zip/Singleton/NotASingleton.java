public class NotASingleton {

    private Integer counter = 0;

    public NotASingleton() {
    }

    public void incrementCounter() {
        counter++;
    }

    public Integer getCounter() {
        return counter;
    }
}
