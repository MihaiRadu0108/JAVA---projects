public class NotASingletonDemo {

    public static void main(String[] args) {

        NotASingleton firstObject = new NotASingleton();
        firstObject.incrementCounter();
        System.out.println(firstObject);

        NotASingleton secondObject = new NotASingleton();
        secondObject.incrementCounter();
        System.out.println(secondObject);

        System.out.println(firstObject.getCounter());
        System.out.println(secondObject.getCounter());
    }
}
