package CRUD;

import jakarta.persistence.EntityManager;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.ArrayList;
import java.util.List;

public class MainCar {
    public static void main(String[] args) {
        final SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Car.class)
                .buildSessionFactory();

        Car volvo = new Car(1L,"XC60","Volvo",2.00);
        Car tesla = new Car(2L,"Model 3","Tesla",0.00);

        EntityManager entityManager = sessionFactory.createEntityManager();
        entityManager.getTransaction().begin();
        //Add cars
        /*  List<Car> carList = new ArrayList<>();
        carList.add(volvo);
        carList.add(tesla);
        carList.forEach(car -> entityManager.persist(car)); */

        //Get all cars from db
        /* List<Car> showRoomCars = new ArrayList<>();
        showRoomCars = entityManager.createQuery("FROM Car", Car.class).getResultList();
        showRoomCars.forEach(car -> System.out.println(car)); */

        // Select a car
        Car car = entityManager.find(Car.class,2L);
        System.out.println(car);

        //Delete a car
        entityManager.remove(car);
        List<Car> carsAfterDelete = entityManager.createQuery("FROM Car", Car.class).getResultList();
        carsAfterDelete.forEach(undeletedCar -> System.out.println(undeletedCar));
        entityManager.getTransaction().commit();



    }


}
