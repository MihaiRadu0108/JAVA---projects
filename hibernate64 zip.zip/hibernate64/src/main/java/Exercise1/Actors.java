package Exercise1;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Actors extends BaseEntity2 {

    private String name;
    private String lastName;
    @Column(name = "yearOfBirth")
    private int yearOfBirth;
    @ManyToMany
    private List<Movies> movies;

}
