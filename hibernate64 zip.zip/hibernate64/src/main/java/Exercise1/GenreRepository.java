package Exercise1;

import jakarta.persistence.EntityManager;

import java.util.List;

public class GenreRepository {
    private final EntityManager entityManager;

    public GenreRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    //adding Genre
    protected void addGenre(Genres genres){
        try {
        entityManager.getTransaction().begin();
        entityManager.persist(genres);
        entityManager.getTransaction().commit();
            System.out.println("Genul " + genres.getName() + " a fost salvat cu succes");
        }catch (Exception e){
            e.getMessage();
        }
    }

    //delete Genre
    protected void deleteGenres(Genres genres){
        try {
            entityManager.getTransaction().begin();
            entityManager.remove(genres);
            entityManager.getTransaction().commit();
            System.out.println("Genul " + genres.getName() + " a fost sters");
        }catch (Exception e){
            e.getMessage();
        }
    }
    //search Genre by name
    protected List<Genres> searchByName(String nume){

        entityManager.getTransaction().begin();
        List<Genres> returnedGenres = entityManager.createQuery("SELECT g FROM Genres g WHERE name = :name")
                .setParameter("name", nume).getResultList();
        entityManager.getTransaction().commit();
        return returnedGenres;

    }

    //search Genre by id
    //display all records from Genres


}
