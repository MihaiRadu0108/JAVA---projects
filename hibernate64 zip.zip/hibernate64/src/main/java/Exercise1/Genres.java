package Exercise1;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Genres extends BaseEntity2 {

    private String name;
    @OneToMany
    @JoinColumn(name = "genre_id")
    private List<Movies> moviesList;


}
