package Exercise1;

import jakarta.persistence.EntityManager;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.ArrayList;
import java.util.List;

public class MainExercise1 {
    public static void main(String[] args) {
        final SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Actors.class)
                .addAnnotatedClass(Movies.class)
                .addAnnotatedClass(Genres.class)
                .buildSessionFactory();

        EntityManager entityManager = sessionFactory.createEntityManager();

        GenreRepository genreRepository = new GenreRepository(entityManager);
        Genres horror = new Genres("Horror",null);
        horror.setId(1);

        Genres comedy = new Genres("Comedy",null);
        comedy.setId(2);

        Genres sf = new Genres("SF",null);
        sf.setId(3);

        Genres drama= new Genres("Drama",null);
        drama.setId(4);

         genreRepository.addGenre(horror);
         genreRepository.addGenre(sf);
         genreRepository.addGenre(comedy);
         genreRepository.addGenre(drama);

       //  genreRepository.deleteGenres(horror);

        List<Genres> returnedGenres = new ArrayList<>();
        returnedGenres = genreRepository.searchByName("Drama");
        returnedGenres.forEach(genres -> System.out.println(genres.getName()));
    }

}
