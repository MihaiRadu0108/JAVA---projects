package Exercise1;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Movies extends BaseEntity2 {

    private String title;
    @Column(name = "year_of_Release")
    private int yearOfRelease;
    @ManyToMany(mappedBy = "movies")
    private List<Actors> actors;

}
