import Entity.Movie;
import MappedSuperclass.ComputerGame;
import jakarta.persistence.EntityManager;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        final SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(ComputerGame.class)
                .buildSessionFactory();
        EntityManager entityManager = sessionFactory.createEntityManager();
        entityManager.getTransaction().begin();
        ComputerGame computerGame = new ComputerGame("Starcraft","Real time strategy","strategy");
        //entityManager.persist(computerGame);
        //computerGame.setId(5);
        //entityManager.remove(computerGame);
        //List<ComputerGame> jocuri = entityManager.createQuery("FROM ComputerGame",ComputerGame.class).getResultList();
        //System.out.println(jocuri);
        ComputerGame joc = entityManager.find(ComputerGame.class,5L);
        System.out.println(joc);

        entityManager.getTransaction().commit();
    }
}
