package ManyToMany;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MainClients2 {
    public static void main(String[] args) {
        final SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Client2.class)
                .addAnnotatedClass(Orders2.class)
                .buildSessionFactory();


    }

}
