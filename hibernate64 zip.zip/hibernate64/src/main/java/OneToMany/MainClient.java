package OneToMany;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MainClient {
    public static void main(String[] args) {
        final SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Client.class)
                .addAnnotatedClass(Orders.class)
                .buildSessionFactory();

    }
}
