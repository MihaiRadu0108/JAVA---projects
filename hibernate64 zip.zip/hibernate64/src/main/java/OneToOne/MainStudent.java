package OneToOne;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MainStudent {
    public static void main(String[] args) {
        final SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Student.class)
                .addAnnotatedClass(StudentBook.class)
                .buildSessionFactory();

    }



}
