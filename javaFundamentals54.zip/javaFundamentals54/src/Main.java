import typesandvariables.DataTypes;

public class Main {

    public static void main(String[] args) {
        System.out.print("Hello World!");
        System.out.println();
        System.out.printf("Numele meu este %s ", "Alina");

        DataTypes object = new DataTypes();
    }

}