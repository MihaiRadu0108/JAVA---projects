import java.util.Scanner;

public class ScannerExample {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Introduceti un text de la tastatura: ");
        String valueFromUser = input.nextLine();

        System.out.println(valueFromUser);
        System.out.println("Introduceti un numar de la tastatura");
        int numberFromInput = input.nextInt();
        input.nextLine(); // trece cursorul pe linie noua pentru urmatoarea cititre de la tastatura

        System.out.println("Valoarea numerica citita de la tastatura este: " + numberFromInput);

        System.out.println("Introduceti adevarat sau fals");
        boolean booleanValue = input.nextBoolean();
        input.nextLine();
        System.out.println("Valoarea booleana citita de la tastatura este: " + booleanValue);

        System.out.println("Introduceti un numar cu virgula");
        double numberWithComma = input.nextDouble();
        System.out.printf("%4.2f", numberWithComma);

    }


}
