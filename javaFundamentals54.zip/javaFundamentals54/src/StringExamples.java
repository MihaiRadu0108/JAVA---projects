
public class StringExamples {

    public static void main(String[] args) {
        String text = "Numele meu este Alina";

        System.out.println(text);

        String anotherText = new String("Ceva");
        String lastText = new String();
        int number = 5;

        String phrase = "Ana are ";

        System.out.println(anotherText);

        System.out.println(text + " " + anotherText);
        System.out.println(text.concat(" ").concat(anotherText));
        System.out.println(phrase.concat(String.valueOf(number)).concat(" mere"));

        System.out.println("Se verifica continutul unui text in al text: " + text.contains("Alina"));

        System.out.println(text.toUpperCase());
        System.out.println(text.length());

        System.out.println("Se verifica egalitatea dintre doua stringuri: " + text.equals(anotherText)); // check equality

        System.out.println("Se verifica pozitia literei m din text: " + text.indexOf("m"));
        System.out.println("Se verifica urmatoarea pozitie a literei m din text: " + text.indexOf("m", 3));

        System.out.println("Se inlocuieste litera a cu litera o in obiectul phrase: " + phrase.replaceAll("a", "o"));
    }

}
