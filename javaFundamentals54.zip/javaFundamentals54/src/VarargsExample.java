public class VarargsExample {

    public static void main(String[] args) {
        VarargsExample example = new VarargsExample();

        System.out.println("Suma a doua numere este: " + example.calculateSum(5, 6));
        System.out.println("Suma a trei numere este: " + example.calculateSum(5, 6, 7));
        System.out.println("Suma numerelor variabile este: " + example.calculateSum(2, 4, 5, 6, 7, 8));

        example.test("Alina", 10, 9, 7, 8);
    }

    public int calculateSum(int... numbers) { // metoda care are varargs (variable arguments) ca si parametru de intrare
        int sum = 0;
        for (int i = 0; i < numbers.length; i++){
            sum = sum + numbers[i];
        }
        return sum;
    }

    public void test(String name, int... note){
    // calculati din variabila note media aritmetica si o afisati la finalul textului de pe linia 22

        System.out.println("Media notelor pentru studentul " + name + " este: ");
    }

//    public int calculateSum(int numberOne, int numberTwo) {
//        return numberOne + numberTwo;
//    }
//
//    public int calculateSum(int numberOne, int numberTwo, int numberThree) {
//        return numberOne + numberTwo + numberThree;
//    }

}
