package arrays;

public class ArrayIterations {

    public static void main(String[] args) {

        int[] numbers = {1, 2, 3, 4, 5, 6, 7};

        for (int i= 0; i < numbers.length ; i++){
            System.out.println(numbers[i]);
        }

        System.out.println("_______________________");

        int[] otherNumbers = new int[10];
        for (int i = 0; i < otherNumbers.length; i++){
            otherNumbers[i] = i*2;
        }

        otherNumbers[0] = -50;

        for (int i = otherNumbers.length - 1; i >= 0; i--){
            System.out.println(otherNumbers[i]);
        }

    }
}
