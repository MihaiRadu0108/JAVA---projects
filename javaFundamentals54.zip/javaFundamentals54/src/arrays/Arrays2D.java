package arrays;

public class Arrays2D {

    public static void main(String[] args) {

        int[][] note = new int[2][3];
        note[0][0] = 10;
        note[0][1] = 9;
        note[0][2] = 10;
        note[1][0] = 8;
        note[1][1] = 9;
        note[1][2] = 10;

        int sumOfElements = 0;
        int countOfElements = 0;
        for (int i = 0; i < note.length; i++) {
            for (int j = 0; j < note[i].length; j++) {
                System.out.println(note[i][j]);
                sumOfElements = sumOfElements + note[i][j];
            }
            countOfElements = countOfElements + note[i].length;
        }
        System.out.println("Media aritmetica a notelor este: " + sumOfElements / (double) countOfElements);

        System.out.println("---------------------------------------");

        String[][] words = {{"sda", "Alina", "Andreea"}, {"Codrut"}, {"Teodor", "Arthur"}};

        int countOfLetters = 0;
        for (int i = 0; i < words.length; i++) {
            for (int j = 0; j < words[i].length; j++) {
                System.out.println("Literele din cuvantul " + words[i][j] + " sunt " + words[i][j].length());
                countOfLetters = countOfLetters + words[i][j].length();
            }
        }

        System.out.println("Numarul total de caractere din array-ul words este: " + countOfLetters);

        String propozitia = "";

        for (int i = 0; i < words.length; i++) {
            for (int j = 0; j < words[i].length; j++) {
                propozitia = propozitia + words[i][j] + " ";
            }
        }
        System.out.println(propozitia);
    }

}
