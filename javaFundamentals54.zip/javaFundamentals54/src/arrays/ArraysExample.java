package arrays;

public class ArraysExample {

    public static void main(String[] args) {

        int[] numbers = new int[5]; // declararea unui array de int-uri cu lungimea de 3 elemente
        numbers[0] = 10; // initializarea valorii de pe pozitia 0 din array
        numbers[1] = -5;
        numbers[2] = 0;
        numbers[4] = 2;

        int[] intNumbers = {5, -1, 2, 6}; // declararea si initializarea valorilor intr-un array
        intNumbers[2] = 3;

        System.out.println(numbers[1]);
        System.out.println(intNumbers[intNumbers.length - 1]);

        String[] words = {"azi", "curs", "sda"};
        System.out.println(words[0]);

        String[] texts = new String[4];
        texts[2] = "Ana are mere";
        texts[0] = "Codrut are mana sus";

        if (texts[0] != null) {
            System.out.println(texts[0].length());
        }

    }

}
