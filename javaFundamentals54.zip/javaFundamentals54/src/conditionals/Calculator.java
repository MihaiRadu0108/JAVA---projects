package conditionals;

import java.util.Scanner;

public class Calculator {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduceti operatia matematica");
        char mathOperation = scanner.nextLine().charAt(0);

        System.out.println("Introuceti primul numar");
        float firstNumber = scanner.nextFloat();
        scanner.nextLine(); // trece cursorul scannerului pe line noua

        System.out.println("Introduceti al doilea numar");
        float secondNumber = scanner.nextFloat();

        switch (mathOperation) {
            case '+':
                System.out.println("Suma este: " + (firstNumber + secondNumber));
               break;
            case '-':
                System.out.println("Diferenta este: " + (firstNumber - secondNumber));
                break;
            case '*':
                System.out.println("Produsul este: " + (firstNumber * secondNumber));
                break;
            case '/':
                System.out.println("Catul este: " + (firstNumber / secondNumber));
                break;
            default:
                System.out.println("Simbolul matematic introdus nu este corect");
        }

    }

}
