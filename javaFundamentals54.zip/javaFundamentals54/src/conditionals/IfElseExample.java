package conditionals;

public class IfElseExample {

    public static void main(String[] args) {
        double temperature = 41;
        if (temperature >= 38) {
            System.out.println("Ai febra!");

            if(temperature > 40){
                System.out.println("Trebuie sa mergi la spital");
            }

        } else {
            System.out.println("Esti sanatos!");
        }

        System.out.println("Finalul programului");
    }

}
