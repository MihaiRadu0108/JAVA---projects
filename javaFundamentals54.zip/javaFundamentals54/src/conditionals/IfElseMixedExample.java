package conditionals;

import java.util.Scanner;

public class IfElseMixedExample {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Introdu temperatura curenta de afara:");
        float temperature = scan.nextFloat();

        if (temperature < 0f) {
            System.out.println("Afara este ger");
        } else if (temperature > 20f) {
            System.out.println("Afara este cald");
        } else {
            System.out.println("Afara este placut");
        }

    }
}
