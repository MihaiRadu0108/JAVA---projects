package conditionals;

public class IfExample {

    public static void main(String[] args) {

        boolean isReady = true;

        if (isReady) {
            System.out.println("Totul e pregatit");
        }

        float temperature = 15.5f;
        if (temperature > 10f && temperature < 20f) {
            System.out.println("Ia o haina pe tine");
        }

        System.out.println("Finalul programului");

    }

}
