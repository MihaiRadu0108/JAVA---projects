package conditionals;

import java.util.Scanner;

public class SwitchExample {

    public static void main(String[] args) {

        Scanner citire = new Scanner(System.in);
        System.out.println("Introdu numele zilei din saptamana");
        String dayOfWeek = citire.nextLine();
        switch (dayOfWeek){
            case "Luni":
                System.out.println("Iarba nu creste");
                break;
            case "Vineri":
                System.out.println("Incepe weekendul");
                break;
            case "Sambata":
            case "Duminica":
                System.out.println("avem curs SDA");
                break;
            default:
                System.out.println("Este mijlocul saptamanii");
        }
    }
}
