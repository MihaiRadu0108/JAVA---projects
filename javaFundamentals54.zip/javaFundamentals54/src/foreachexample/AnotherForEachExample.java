package foreachexample;

public class AnotherForEachExample {

    public static void main(String[] args) {
        String[] words = {"Luni", "Sambata", "Duminica" };
        AnotherForEachExample object = new AnotherForEachExample();
        object.showElements(words);
    }

    public void showElements(String[] words) {
        for (String word : words) {
            System.out.println(word);
        }
    }

}
