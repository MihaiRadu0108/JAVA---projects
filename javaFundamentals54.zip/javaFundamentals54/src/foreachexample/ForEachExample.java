package foreachexample;

public class ForEachExample {
    //  Sa se faca media aritmetica intre suma si produsul elementelor unui sir de numere cu n elemente
    public static void main(String[] args) {

        int[] myIntArray = {5, 4, 3, 2, 1, 10, 9, 8, 7, 6};
        ForEachExample name = new ForEachExample();
        System.out.println(name.calculateAverage(myIntArray));
        System.out.println(name.calculateAverageWithForEach(myIntArray));
    }

    public float calculateAverage(int[] numbers) {
        int sum = 0;
        int product = 1;
        for (int i = 0; i < numbers.length; i++) {
            sum = sum + numbers[i];
            product = product * numbers[i];
        }
        return (sum + product) / 2f;
    }

    public float calculateAverageWithForEach(int[] numbers) {
        int sum = 0;
        int product = 1;
        for (int element : numbers) {
            sum = sum + element;
            product = product * element;
        }
        return (sum + product) / 2f;
    }

}
