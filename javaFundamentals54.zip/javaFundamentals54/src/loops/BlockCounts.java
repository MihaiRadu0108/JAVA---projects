package loops;

import java.util.Scanner;

public class BlockCounts {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Cate nivele are piramida?");
        int numberOfLevels = scanner.nextInt();
        int totalNumbersOfCubes = 0;

        for (int i = 1; i <= numberOfLevels; i++) {
            totalNumbersOfCubes = totalNumbersOfCubes + i * i;
        }

        System.out.println("Numarul total de cuburi necesare pentru a face o piramida de "
                + numberOfLevels + " nivele este: " + totalNumbersOfCubes);
    }
}
