package loops;

import java.util.Random;

public class DiceGame {

    public static void main(String[] args) {

        Random rand = new Random();
        int diceOne;
        int diceTwo;
        do {
            diceOne = rand.nextInt(6) + 1;
            diceTwo = rand.nextInt(1, 7);
            System.out.println("Zarul unu este: " + diceOne + ", zarul doi este " + diceTwo);
        } while (diceOne != diceTwo);

    }
}
