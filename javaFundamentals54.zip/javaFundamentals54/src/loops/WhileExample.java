package loops;

public class WhileExample {

    public static void main(String[] args) {
        int value = 1;
        while (value < 10) {
            System.out.println("Hello Alina");
            value++;
        }

        System.out.println("Finalizarea programului");
    }

}
