package methods;

public class MethodsExample {

    public static void main(String[] args) {
        printName("Alina");
        String fullName = createFullName("Teodor", "Istrate");
        System.out.println("Numele meu intreg este " + fullName);
        int sumOfNumbers = sumOfIntNumbers(2, 3);

        System.out.println("Suma numerelor este " + sumOfNumbers);
    }

    public static String createFullName(String firstName, String lastName) {
        String fullName = firstName + " " + lastName;
        return fullName;
    }

    public static void printName(String name) {
        System.out.println(name);
    }

    public static int sumOfIntNumbers(int firstNumber, int secondNumber) {
        return firstNumber + secondNumber;
    }

    public static void sum(int firstNumber, int secondNumber) {
        System.out.println(firstNumber + secondNumber);
    }

}









