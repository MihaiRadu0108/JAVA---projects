package methods;

import java.util.Scanner;

public class SimpleMethodExample {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introdu un numar care sa fie verificat");
        int numberFromUser = scanner.nextInt();

        SimpleMethodExample example = new SimpleMethodExample();

        example.checkNumber(numberFromUser);
        example.print();

    }

    public void checkNumber(int numberToBeChecked) {
        if (numberToBeChecked % 2 != 0) {
            System.out.println("Numarul este impar si nu il vom afisa");
            return;
        }
        System.out.println("Numarul verificat este par: " + numberToBeChecked);
    }

    public void print(){
        System.out.println("Hello Alina");
    }


}
