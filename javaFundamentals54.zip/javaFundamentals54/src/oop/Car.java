package oop;

public class Car {
    // zona de declarare a campurilor clasei (fields)
    private String color;
    private int speed;
    private String brand;
    private String motor;

    public Car() {
        this.motor = "diesel de 1.4";
    }

    public Car(String color, int speed, String brand) {
        this(color, brand);
        this.speed = speed;
    }

    public Car(String color, String brand){
        this();
        this.color = color;
        this.brand = brand;
    }


    // zona de declarare a metodelor clasei (comportamentele obiectelor)
    public void printCarParameters() {
        System.out.printf("Culoarea masinii este %s, viteza este %s, marca este %s si motorul %s \n", color, speed, brand, motor);
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getColor() {
        return color;
    }

    public int getSpeed() {
        return speed;
    }

    public String getBrand() {
        return brand;
    }

}
