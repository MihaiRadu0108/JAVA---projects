package oop;

import oop.book.Book;

public class Main {

    public static void main(String[] args) {
        Car toyota = new Car();
        Car mazda = new Car();

        toyota.setColor("red");
        toyota.setSpeed(123);
        toyota.setBrand("Toyota");

        mazda.setBrand("Mazda");
        mazda.setSpeed(200);
        mazda.setColor("pink");

        toyota.printCarParameters();
        mazda.printCarParameters();
        System.out.println(toyota.getColor());

        Car audi = new Car("black", 250, "Audi");
        audi.printCarParameters();

        Car citroen = new Car("alb", 180, "Citroen");
        citroen.printCarParameters();

        Car dacia = new Car("albastru", "Dacia");
        dacia.printCarParameters();

        System.out.println("------------------------------");
        Book luceafarul = new Book();
        luceafarul.setNumberOfPages(100);
        luceafarul.setAuthor("Mihai Eminescu");
        luceafarul.name = "Luceafarul";
        System.out.println(luceafarul);
        System.out.println(luceafarul.getAuthor());
        oop.anotherbook.Book anotherBook = new oop.anotherbook.Book(); // cand ai nevoie de o clasa cu acelasi nume din alt pachet
    }

}
