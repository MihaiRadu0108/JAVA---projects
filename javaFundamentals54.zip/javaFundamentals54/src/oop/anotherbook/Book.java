package oop.anotherbook;

public class Book {


}
