package oop.book;

public class Book {
    public String name; // modificator de acces public
    private String author;
    private int numberOfPages;

    public void setAuthor(String nameOfAuthor){
        author = nameOfAuthor;
    }

    public String getAuthor(){
        return author;
    }

    public void setNumberOfPages(int numberOfPages){
        if(checkNumberOfPages(numberOfPages)){
            this.numberOfPages = numberOfPages;
        }
    }

    boolean checkNumberOfPages(int numberOfPages){
        return numberOfPages > 0;
    }

    @Override
    public String toString() {
        return "Book{" +
                "name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", numberOfPages=" + numberOfPages +
                '}';
    }

}
