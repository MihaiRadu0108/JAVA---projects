package oop.classes;

public class MyOuterClass {
    private static String name = "Alina";

    public static class MyInnerClass {
        public void printName() {
            System.out.println(name);
        }
    }

}
