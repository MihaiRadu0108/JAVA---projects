package oop.classes;

public class MyPrinter {

    public static int daysInAWeek = 7;
    public int minutesInAnHour = 60;

    public static void printNumber(int number){
        System.out.println("This number is " + number);
    }

    public void printMinutesInAWeek(){
        System.out.println("In a week there are " + minutesInAnHour * 24 * daysInAWeek);
    }

}
