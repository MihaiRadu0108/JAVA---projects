package oop.classes;

public class MyPrinterExample {

    public static void main(String[] args) {
        MyPrinter.printNumber(6); // call a static method from MyPrinter class
        System.out.println(MyPrinter.daysInAWeek);

        MyPrinter objectFromMyPrinterClass = new MyPrinter();
        objectFromMyPrinterClass.printMinutesInAWeek(); // call a nonstatic method from MyPrinter class
        System.out.println(objectFromMyPrinterClass.minutesInAnHour);

        MyOuterClass objectFromOuter = new MyOuterClass();
        MyOuterClass.MyInnerClass objectFromInner = new MyOuterClass.MyInnerClass();
        objectFromInner.printName();

    }

}
