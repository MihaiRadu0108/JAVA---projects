package typesandvariables;

public class DataTypes {

    public static void main(String[] args) {
        // cele 4 tipuri de date pentru numere intregi
        byte firstByte = -127;
        short firstShort = 32767;
        int myIntNumber = 32768;
        long myLongNumber = 4565;

        System.out.println(firstByte);

        long sum = Integer.MAX_VALUE + 1L;

        System.out.println(sum);

        // cele 2 tipuri de date pentru numere cu virgula
        float myFloatNumber = 5.5568f;
        double myDoubleNumber = 10.509;

        System.out.println(myFloatNumber);
        System.out.printf("%.2f", myDoubleNumber);
        System.out.println("\n\n\n");
        System.out.printf("%.3f", myFloatNumber);
        System.out.println();

        boolean myBooleanValue = true;
        System.out.println(myBooleanValue);

        char myCharValue = 'c';

        System.out.println(myCharValue);
    }


}
