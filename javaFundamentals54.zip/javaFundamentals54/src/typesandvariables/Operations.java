package typesandvariables;

public class Operations {

    public static void main(String[] args) {
        // operatii de asignare
        int a = 5;
        a += 10;
        System.out.println(a);
        a *= 2;
        System.out.println(a);
        a -= 3;
        System.out.println(a);
        a /= 2;
        System.out.println(a);

        int firstNumber = 5;
        int secondNumber = 2;

        float result = (float) firstNumber / secondNumber;

        System.out.println(firstNumber / secondNumber);
        System.out.println(result);

        double division = 7 / (double) 2;

        System.out.println(division);

        char someCharacter = 'a';

        System.out.println((double) someCharacter);

        int restOfDivision = firstNumber % secondNumber;
        System.out.println(restOfDivision);

        System.out.println("x = " + restOfDivision + " orice vrei tu " + someCharacter);

        int someVariable = 5;
        someVariable++; // prescurtarea de la someVariable = someVariable + 1;
        System.out.println(someVariable);
        someVariable--; // prescurtarea de la someVariable = someVariable - 1;
        System.out.println(someVariable);

        // operatori de relationare
        boolean checkEqualityBetweenTwoNumbers = someVariable == 5;
        System.out.println(checkEqualityBetweenTwoNumbers);
        boolean checkInequalityBetweenTwoNumbers = someVariable != division;
        System.out.println(checkInequalityBetweenTwoNumbers);

        // operatori logici
        System.out.println("Operatori logici");
        boolean firstBooleanValue = true;
        boolean secondBooleanValue = false;

        System.out.println(firstBooleanValue && secondBooleanValue);
        System.out.println(firstBooleanValue || secondBooleanValue);
        System.out.println(!firstBooleanValue);
        System.out.println(firstBooleanValue && (!secondBooleanValue) || firstBooleanValue);

    }

}
