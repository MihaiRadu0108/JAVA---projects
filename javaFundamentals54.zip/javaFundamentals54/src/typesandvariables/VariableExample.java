package typesandvariables;

public class VariableExample {

    public int value;  // declararea unei variabila globale

    /*
    Comentariu foarte lung
     */
    public static void main(String[] args) {

        int number;  // declararea unei variabile locale
        number = 5; // initializarea unei variabile

        System.out.println(number);

        int secondNumber = 10;  // declarare si initializare
        System.out.println(secondNumber);

        int numberOfMinutesInADay = 60 * 24;

        boolean is4You = true;

    }

}
